<?php
/* Template Name: Areas */
get_header();
?>



<?php
get_footer();
?>